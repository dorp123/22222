console.log("check");

function ex9() {
    var toti=0;
    toti=Number(toti);
    for (var mehirim=prompt("tap prices,for total tap 0");mehirim!=0;){
        mehirim=Number(mehirim);
       
 toti+=mehirim;
  var mehirim=prompt("tap prices,for total tap 0")
 
    }
 alert (toti);
 
         }