console.log("check");



function ex4() {

    var size = document.getElementById("size").value;
    if (size >= 24 && size <= 30) {
        massages();
    }
     else if (size >= 31 && size <= 36) {
        massagem();
    }
    else if  (size > 36) {
        massagel();


    }
    else massagenosize();

}

function massages() {
    document.getElementById("massageForUser").innerHTML = "מידתך היא S";
    document.getElementById("massageForUser").style.color = "red";


}

function massagem() {
    document.getElementById("massageForUser").innerHTML = "מידתך היא M";
    document.getElementById("massageForUser").style.color = "green";

}
function massagel() {
    document.getElementById("massageForUser").innerHTML = "מידתך היא L";
    document.getElementById("massageForUser").style.color = "green";

}
function massagenosize() {
    document.getElementById("massageForUser").innerHTML = "אין לנו מידות כאלה";
    document.getElementById("massageForUser").style.color = "green";

}
