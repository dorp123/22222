console.log("check");

function ex7() {
    var tot=0;
    tot=Number(tot);
for(var hacol=prompt("tap number");hacol>0;hacol--){

hacol=Number(hacol);
tot+=hacol;


}
alert (tot);



}