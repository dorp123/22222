console.log("check")

function ex1() {

var gil= document.getElementById("age").value;
if (gil <= 16) {
    massage();
} else {
   massagenot();
}

}

function massage() {
    document.getElementById("massageForUser").innerHTML = "אתה לא יכול לנהוג";
    document.getElementById("massageForUser").style.color = "red";


}

function massagenot() {
    document.getElementById("massageForUser").innerHTML = "אתה יכול להתחיל לנהוג";
    document.getElementById("massageForUser").style.color = "green";

}
