console.log("check");
 function ex6() {

            var uname = prompt("הקש שם משתמש");
            var upass = prompt("הקש סיסמא");

            if (uname == "" && upass == "") {
                alert("נא הקש שם משתמש וסיסמא")
            }
            else if (uname == "") {
                alert("נא הקש שם משתמש")
            }
            else if (upass == "") {
                alert("הקש סיסמא")
            }
            else if (uname == "hackeru" && upass == "hackeru123") {
                alert("welcome");
            } else alert("not welcome");




        }















function ex6() {

    var uname = document.getElementById("uName").value;
    var upass = document.getElementById("uPass").value;

    if (uname == "" && upass == "") {
        massage2();
    }
     else if (uname == "") {
        massageun();
    }
    else if  (upass == "") {
        massageup();


    }
    else if  (uname == "hackeru" && upass == "hackeru123") {
        massagew();


    }
    else massagen();

}

function massage2() {
    document.getElementById("massageForUser").innerHTML = "נא הקש שם משתמש וסיסמא";
    document.getElementById("massageForUser").style.color = "red";


}

function massageun() {
    document.getElementById("massageForUser").innerHTML = "נא הקש שם משתמש";
    document.getElementById("massageForUser").style.color = "green";

}
function massageup() {
    document.getElementById("massageForUser").innerHTML = "הקש סיסמא";
    document.getElementById("massageForUser").style.color = "green";

}
function massagew() {
    document.getElementById("massageForUser").innerHTML = "welcome";
    document.getElementById("massageForUser").style.color = "green";

}
function massagen() {
    document.getElementById("massageForUser").innerHTML = "not welcome";
    document.getElementById("massageForUser").style.color = "green";

}
