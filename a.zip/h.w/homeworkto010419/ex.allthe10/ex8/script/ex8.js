console.log("check")

function ex8() {

var num= document.getElementById("number").value;
if (num == 0) {
    massagezero();
} else if  (num % 2 == 0 ){
    massagezugi();
 }
 else {
    massagelozugi();
 }

}

function massagezero() {
    document.getElementById("massageForUser").innerHTML = "מספר זה ניטרלי";
    document.getElementById("massageForUser").style.color = "red";


}

function massagezugi() {
    document.getElementById("massageForUser").innerHTML = "מספר זה זוגי";
    document.getElementById("massageForUser").style.color = "green";

}
function massagelozugi() {
    document.getElementById("massageForUser").innerHTML = "מספר זה אי זוגי";
    document.getElementById("massageForUser").style.color = "green";

}
