console.log("check");


function ex5() {
    var totali = 0;
    totali = Number(totali);
    for (var l = 0; l < 5; l++)
    {

        var sehum = prompt("tap number")
        sehum = Number(sehum)
        totali += sehum

    }
    alert(totali);

}