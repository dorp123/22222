console.log("check");



function ex3() {
    var userPass = document.getElementById("uPass").value;

    var userName = document.getElementById("uName").value;
    if (userName == "hackeru" && userPass == "hackeru123") {
        massage();
    } else massagenot();
}


function massage() {
    document.getElementById("massageForUser").innerHTML = "welcome";
    document.getElementById("massageForUser").style.color = "green";


}

function massagenot() {
    document.getElementById("massageForUser").innerHTML = "not welcome";
    document.getElementById("massageForUser").style.color = "red";

}
