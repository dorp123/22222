
console.log("check")

function ex2() {

    var gil = document.getElementById("age").value;
    if (gil <= 16) {
        massage();
    }
     else if (gil <= 18) {
        massagenot();
    }
    else if  (gil <= 70) {
        massagecan();


    }
    else massagecant();

}

function massage() {
    document.getElementById("massageForUser").innerHTML = "אתה לא יכול לנהוג";
    document.getElementById("massageForUser").style.color = "red";


}

function massagenot() {
    document.getElementById("massageForUser").innerHTML = "אתה יכול להתחיל ללמוד נהיגה";
    document.getElementById("massageForUser").style.color = "green";

}
function massagecan() {
    document.getElementById("massageForUser").innerHTML = "אתה יכול לנהוג";
    document.getElementById("massageForUser").style.color = "green";

}
function massagecant() {
    document.getElementById("massageForUser").innerHTML = "אתה יכול לנהוג בהמלצת רופא";
    document.getElementById("massageForUser").style.color = "green";

}
