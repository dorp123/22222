console.log("check");

function ex10() {
    var mishpat = ""
    for(var mila=prompt("הקש מספר מילים");mila>0;mila--){
    var stami=prompt("הקש מילה");
    mishpat+=" ";
    mishpat+=stami;
    
    
    
    }
    alert(mishpat)
    
            }
    