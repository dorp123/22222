function colorbox2() {
    var tseva = document.getElementById("colorbg2").value;
    var gova = document.getElementById("height").value;
    var rohav = document.getElementById("width").value;
    document.getElementById("box2").innerHTML +=
     " <div style='height:"+gova+"px;width:"+ rohav +"px;background-color:" + tseva + "'>  <div/> "


}