console.log("check")

function colorbox() {
    var tseva = document.getElementById("colorbg").value;
    document.getElementById("box").innerHTML +=
     " <div style='height:100px;width:100px;background-color:" + tseva + "'>  <div/> "


}

