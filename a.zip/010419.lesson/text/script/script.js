console.log("check conection");



function add() {

    console.log("check");


    var width = document.getElementById("width").value;
    var height = document.getElementById("height").value;
    var bgcolor = document.getElementById("bgcolor").value;
    var pxborder = document.getElementById("pxborder").value;
    var colorborder = document.getElementById("colorborder").value;
    var fontselected = document.getElementById("selectfont").value;
    var pixel = document.getElementById("pxtext").value;
    var melel = document.getElementById("tohen").value;


    var mynewelement = document.createElement("div");
    mynewelement.style.width = width + "px";
    mynewelement.style.height = height + "px";
    mynewelement.style.backgroundColor = bgcolor;
    mynewelement.style.borderWidth = pxborder + "px";
    mynewelement.style.borderColor = colorborder;
    mynewelement.style.borderStyle = "solid";
    mynewelement.style.fontFamily = fontselected;
    mynewelement.style.fontSize = pixel + "px";
    mynewelement.innerHTML = melel;

    document.getElementById("box").appendChild(mynewelement);




}