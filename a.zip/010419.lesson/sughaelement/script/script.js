console.log("check");



var mispar = 0;

function add() {

    var width = document.getElementById("width").value;
    var height = document.getElementById("height").value;
    var bgcolor = document.getElementById("bgcolor").value;
    var pxborder = document.getElementById("pxborder").value;
    var colorborder = document.getElementById("colorborder").value;
    var fontselected = document.getElementById("selectfont").value;
    var pixel = document.getElementById("pxtext").value;
    var melel = document.getElementById("tohen").value;
    var mynewelement = document.getElementById("selectelement").value;

    console.log(width, height, bgcolor, pxborder, colorborder, fontselected, pixel, melel, mynewelement);

    var myelement = document.createElement(mynewelement);
    myelement.style.width = width + "px";
    myelement.style.height = height + "px";
    myelement.style.backgroundColor = bgcolor;
    myelement.style.borderStyle = "solid";
    myelement.style.borderWidth = pxborder + "px";
    myelement.style.borderColor = colorborder;
    myelement.style.fontFamily = fontselected;
    myelement.style.fontSize = pixel + "px";
    myelement.innerHTML = melel;
    myelement.id = "thebox" + mispar;

    myelement.title = 'the element: ' + mynewelement + ', element width and height: ' + width + 'px ,' + height + ' px, background color: ' + bgcolor + ', border size: ' + pxborder + 'px, color border : ' + colorborder + ', font family: ' + fontselected + ', font size: ' + pixel + ' px ,id: ' + myelement.id;

    mispar++;


    document.getElementById("box").appendChild(myelement);

}