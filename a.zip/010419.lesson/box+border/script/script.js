console.log("check");


function add() {
    console.log("checkfunction")
    var width = document.getElementById("width").value;
    var height = document.getElementById("height").value;
    var bgcolor = document.getElementById("bgcolor").value;
    var pxborder = document.getElementById("pxborder").value;
    var colorborder = document.getElementById("colorborder").value;
    console.log(width, height, color, pxborder, colorborder);

    var mynewbox = document.createElement("div");
    mynewbox.style.width = width + "px";
    mynewbox.style.height = height + "px";
    mynewbox.style.backgroundColor = bgcolor;
    mynewbox.style.borderWidth = pxborder + "px";
    mynewbox.style.borderStyle = "solid";
    mynewbox.style.borderColor = colorborder;

    document.getElementById("box").appendChild(mynewbox);





}