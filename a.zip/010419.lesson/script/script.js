console.log("check");



function add() {
    console.log("check")
    var width = document.getElementById("width").value;
    var height = document.getElementById("height").value;
    var bgcolor = document.getElementById("bgcolor").value;

    console.log(width, height, bgcolor)

    var mynewdiv = document.createElement("div");
    mynewdiv.style.width = width + "px";
    mynewdiv.style.height = height + "px";
    mynewdiv.style.backgroundColor = bgcolor;
    document.getElementById("box").appendChild(mynewdiv);
}