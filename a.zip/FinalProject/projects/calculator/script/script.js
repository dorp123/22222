console.log("into");
var modulu=0;
var total=0;
var total1=0;
var siman=""; 

//פוקציה שאומרת שמתי שמודולו מודולו 2 =0 היא מבצעת שירשור למספר הראשון
function numberTap(elm){
 var a=  document.getElementById("part1").innerHTML;
    if(document.getElementById("part1").innerHTML==total*1+"."){
       a+=elm.innerHTML;
       document.getElementById("part1").innerHTML=(a*1);
       console.log(a*1);

return;


    }
   if (modulu%2==0){
    
elm.innerHTML=Number(elm.innerHTML);
total+=elm.innerHTML;

document.getElementById("part1").innerHTML=(total*1);

console.log(total);
//פוקציה שאומרת שמתי שמודולו מודולו 2 =1 היא מבצעת שירשור למספר השני

} else {
    elm.innerHTML=Number(elm.innerHTML);
total1=Number(total1);
total1+=elm.innerHTML;

document.getElementById("part1").innerHTML=(total1*1);

console.log(total1);
}

}

function things(changing){
    total=document.getElementById("part1").innerHTML;
if(total!=document.getElementById("part1").innerHTML){}
    document.getElementById("part1").innerHTML=(changing.innerHTML);
  siman=changing.innerHTML;
  total1=Number(total1);



  if(modulu==1){ 
    
      
    
  if (siman=="*"){
      total=total*total1;
  }else if(siman=="-"){
      total-=total1;
  }else if(siman=="+"){
      total+=total1;
    }else if(siman=="/"){
        total=total/total1;
   
    }
}

  document.getElementById("part1").innerHTML=(total*1);

  
  total1=0;

if(modulu==0){
  modulu++;}
  else{modulu=1};

}
function myResult(){
total=Number(total);
total1=Number(total1);

if (siman=="*"){
    total*=total1;
}else if(siman=="-"){
    total-=total1
}else if(siman=="+"){
    total+=total1
}else if(siman=="/"){
    total/=total1
}

document.getElementById("part1").innerHTML=(total);

total1=0;
modulu++;

}
function restart(){
    modulu=0;
 total=0;
 total1=0;
 siman="";
 document.getElementById("part1").innerHTML=(0);

}
function minusPlus()
{
total*=-1;
document.getElementById("part1").innerHTML=(total);

}
function achuz(){
total/=100;
document.getElementById("part1").innerHTML=(total);
}
function point(){

    document.getElementById("part1").innerHTML=(total*1+".");



}



