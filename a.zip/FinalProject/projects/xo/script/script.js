console.log("into");







var move = 0;
finishgame = false;


function playGame(elm) {
    if (finishgame == false) {
        console.log(elm);
        console.log(elm.id);

        if (elm.innerHTML != "") {
            return;
        }

        if (move % 2 == 0) {
            elm.innerHTML = "    <img style=width:100%;height:100%; src='images/x.png'> ";

        } else {
            elm.innerHTML = "    <img style=width:100%;height:100%; src='images/o.png'> ";

        }

        move++;


        if (move > 4) {

            if (elm.id == "n0") {
                checkSet("n0", "n1", "n2");
                checkSet("n0", "n4", "n8");
                checkSet("n0", "n3", "n6");


            } else
            if (elm.id == "n1") {
                checkSet("n0", "n1", "n2");
                checkSet("n1", "n4", "n7");


            } else
            if (elm.id == "n2") {
                checkSet("n0", "n1", "n2");
                checkSet("n2", "n5", "n8");
                checkSet("n2", "n4", "n6");


            } else
            if (elm.id == "n3") {
                checkSet("n3", "n4", "n5");
                checkSet("n3", "n1", "n6");


            } else
            if (elm.id == "n4") {
                checkSet("n0", "n4", "n8");
                checkSet("n4", "n1", "n7");
                checkSet("n4", "n3", "n5");
                checkSet("n4", "n2", "n6");


            } else
            if (elm.id == "n5") {
                checkSet("n5", "n4", "n3");
                checkSet("n5", "n2", "n8");


            } else
            if (elm.id == "n6") {
                checkSet("n6", "n7", "n8");
                checkSet("n6", "n4", "n2");
                checkSet("n0", "n3", "n6");


            } else
            if (elm.id == "n7") {
                checkSet("n7", "n1", "n4");
                checkSet("n7", "n6", "n8");


            } else if (elm.id == "n8") {
                checkSet("n8", "n7", "n6");
                checkSet("n8", "n4", "n0");
                checkSet("n8", "n2", "n5");


            }
        }


    }
}

function checkSet(id1, id2, id3) {


    var txt1 = document.getElementById(id1).innerHTML;
    var txt2 = document.getElementById(id2).innerHTML;
    var txt3 = document.getElementById(id3).innerHTML;

    console.log(txt1, txt2, txt3);
    if (txt1 == txt2 && txt2 == txt3) {
        console.log("win");
        var piska = document.getElementById("messageForUser");
        piska.style.color = "green";
        piska.innerHTML = "winner!"
        piska.style.textAlign = "center";
        finishgame = true;
    }



}

function reset() {
    console.log("intofunc");
    document.getElementById("n0").innerHTML = "";
    document.getElementById("n1").innerHTML = "";
    document.getElementById("n2").innerHTML = "";
    document.getElementById("n3").innerHTML = "";
    document.getElementById("n4").innerHTML = "";
    document.getElementById("n5").innerHTML = "";
    document.getElementById("n6").innerHTML = "";
    document.getElementById("n7").innerHTML = "";
    document.getElementById("n8").innerHTML = "";
    finishgame = false;
    document.getElementById("messageForUser").innerHTML = "";


}