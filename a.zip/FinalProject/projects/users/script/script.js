console.log("check");

var users = [];


function addUser() {
    console.log("checkf");
    var userNames = document.getElementById("uName").value;
    console.log(userNames);
    users.push(userNames);
    console.log(users);

}

function search(){
    var lastUser= document.getElementById("searchUser").value;
var checkbulian= users.includes(lastUser);
console.log(checkbulian);
if(checkbulian==true){

    alert("user available");

}
else alert ("user not available");

}

function uSwitch() {
    console.log("get into func");
 var now= document.getElementById("uNow").value;
 if (users.includes(now)==true){
     var a= users.indexOf(now);
     console.log(a);
  var new2=  document.getElementById("uNew").value;
  users[a]=new2;
}
  else alert ("user not available");



 }
