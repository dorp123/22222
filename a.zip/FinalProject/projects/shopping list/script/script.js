console.log("check");
/*

var mylist = [];

function add() {

    var lakahat = prompt("tap product");
    mylist.push(lakahat);
    console.log(mylist);



}

function print() {

    for (var i = 0; i < mylist.length; i++)
        console.log(mylist[i]);



}*/

var maarah = [];


function addp() {
    console.log("checkf");
    var pro = document.getElementById("product").value;
    maarah.push(pro);
    console.log(maarah);

}
console.log(maarah);


function print() {
    document.getElementById("mylist").innerHTML = "";
    console.log("checkf2");
    for (var i = 0; i < maarah.length; i++) {
        var mutsar = document.createElement("li");

        mutsar.innerHTML = maarah[i];
        document.getElementById("mylist").appendChild(mutsar);
    }

}