console.log("check");

function onoff() {
var change= document.getElementById("photo").alt;

if (change=="off") {
    console.log(change);
document.getElementById("photo").src="images/led2.png";
document.getElementById("massage").innerHTML="tap to tern off";
var change= document.getElementById("photo").alt="on";

}
else {
    document.getElementById("photo").src="images/led1.png";
    document.getElementById("massage").innerHTML="tap to tern on";
    var change= document.getElementById("photo").alt="off";



}







}