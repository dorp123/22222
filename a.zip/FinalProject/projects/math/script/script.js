window.onload = function () {
    console.log("into");

    document.getElementById("num1").innerHTML = getNumber();
    document.getElementById("num2").innerHTML = getNumber();




    function getNumber() {

        return Math.floor(Math.random() * 10 + 1)



    }
    document.getElementById("checkAnswer").addEventListener("click", function ()

        {
            console.log("checkintofunction");
            var first = document.getElementById("num1").innerHTML;
            console.log(first)
            first = Number(first);
            var second = document.getElementById("num2").innerHTML;
            second = Number(second);
            var answer = document.getElementById("answerIs").value;
            answer = Number(answer);

            console.log(first, second);

            if (first + second == answer) {
                document.getElementById("messageForUser").innerHTML = "התשובה נכונה";
                document.getElementById("messageForUser").style.color = "green";


            } else {
                document.getElementById("messageForUser").innerHTML = "התשובה אינה נכונה";
                document.getElementById("messageForUser").style.color = "red";


            }


        }
    );





}

function change() {
    console.log("get into change");
    document.getElementById("num1").innerHTML = getNumber();
    document.getElementById("num2").innerHTML = getNumber();




    function getNumber() {

        return Math.floor(Math.random() * 10 + 1)



    }
    document.getElementById("messageForUser").innerHTML = "";
    document.getElementById("answerIs").value = "";

} // התרגיל,מה שאתה ענית,התשובה הנכונה,כמה נקודות //