console.log("start");
var scores = [];

var sah = 0;
sah = Number(sah);

function add() {


    console.log("checkfunc1");
    var userScores = document.getElementById("score").value;
    userScores = Number(userScores);
    var newTab = document.createElement("tr");
    newTab.innerHTML = '<td style="border: 1px solid balck;" id="tidi">score</td> <td>' + userScores + '</td>';
    //  document.getElementById("tavla").style.border = "1px solid black";//

    document.getElementById("tavla").appendChild(newTab);
    console.log(userScores);
    scores.push(userScores);
    sah += userScores;
    console.log(sah);


}






function toconsole() {
    console.log("checkfunc2");
    console.log(scores);
}

function memutsa() {
    console.log("checkfunc3");
    var m = sah;
    m /= scores.length;
    console.log(m);


}