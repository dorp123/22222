/*console.log("mashu")
var uName = prompt("tap uname");
var uPass = prompt("tap pass");
if (uName == "hackeru" && uPass == "hackeru123") {

    var fullname = prompt("tap full name");
    alert("welcome" + " " + fullname);
} else alert("not welcome");
*/
function sayholla() {
    alert("say holla");
    console.log("say holla");

}

function sabahelhir() {

    alert("sabah el hir");
    console.log("sabah el hir");


}
sayholla();
sabahelhir();