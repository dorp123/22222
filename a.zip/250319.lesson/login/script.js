console.log("mashehu")




function login() {
    var uName = document.getElementById("inputUname").value;
    var uPass = document.getElementById("inputPass").value;
    if (uName == "hackeru" && uPass == "hackeru123") {
        massage();
    } else massagenot()



}

function massage() {
    document.getElementById("massageForUser").innerHTML = "welcome";
    document.getElementById("massageForUser").style.color = "green";


}

function massagenot() {
    document.getElementById("massageForUser").innerHTML = "not welcome";
    document.getElementById("massageForUser").style.color = "red";

}

function colorbox() {
    var tseva = document.getElementById("colorbg").value;
    document.getElementById("box").innerHTML += " <div style='border:1px solid red;height:100px;width:100px;background-color:" + tseva + "'>  <div/> "


}