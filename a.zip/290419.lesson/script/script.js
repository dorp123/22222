console.log("into");
console.log($);









$("#myBox1 button").click(function () {
    console.log("into event");
    $("#myBox1").fadeOut();
});