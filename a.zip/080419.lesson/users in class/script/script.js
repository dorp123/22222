console.log("start");
var users = [];

function addUser() {
    console.log("checkfunc");
    var newUser = document.getElementById("userName").value;
    var ifIncludes = false;
    for (var i = 0; i < users.length; i++) {
        if (newUser == users[i]) {
            ifIncludes = true;
        }
    }

    if (ifIncludes == true) {
        document.getElementById("massageForUser").innerHTML = "the user already exist";
        document.getElementById("massageForUser").style.color = "red"

    } else {
        users.push(newUser);
        document.getElementById("massageForUser").innerHTML = "the user added";
        document.getElementById("massageForUser").style.color = "green"


    }
    console.log(users);

}

function searchUser() {

    console.log("intofunc");
    var search = document.getElementById("search").value;
    var searchIncludes;
    for (var i = 0; i < users.length; i++) {
        if (search == users[i]) {
            searchIncludes = true;

        }
    }

    if (searchIncludes == true) {
        document.getElementById("bdika").innerHTML = "the user exist";
        document.getElementById("bdika").style.color = "green"

    } else {

        document.getElementById("bdika").innerHTML = "the user not axist";
        document.getElementById("bdika").style.color = "red"
    }
}