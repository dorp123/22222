console.log("check");

var users = [];


function addUser() {
    console.log("checkf");
    var userNames = document.getElementById("uName").value;
    console.log(userNames);
    users.push(userNames);
    console.log(users);

}