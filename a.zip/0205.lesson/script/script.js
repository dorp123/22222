console.log("into");

var yesNo = true;

$("#btnSend").click(function () {

    console.log("intoevent");
    var checkName = /^[a-zA-Zא-ת ]+$/;

    var nameVal = $.trim($("#firstName").val());
    var lastNameVal = $.trim($("#lastName").val());

    if (nameVal.length < 2 || nameVal.length > 40 || !checkName.test(nameVal)) {
        $("#firstName").val('');
        $("#firstName").addClass("error");
        $("#firstName").attr("placeholder", "enter firstname");

        yesNo = false;
    } else {
        $("#firstName").removeClass("error");
    }
    if (lastNameVal.length < 2 || lastNameVal.length > 40 || !checkName.test(lastNameVal)) {
        $("#lastName").val('');
        $("#lastName").addClass("error");
        $("#lastName").attr("placeholder", "enter lastname");
        yesNo = false;
    } else {
        $("#lastName").removeClass("error");
    }





});